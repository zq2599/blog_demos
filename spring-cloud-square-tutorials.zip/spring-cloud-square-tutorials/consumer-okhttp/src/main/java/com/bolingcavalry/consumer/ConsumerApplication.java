package com.bolingcavalry.consumer;

import okhttp3.OkHttpClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Date;
import java.util.List;
//import java.util.Random;
//import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * @author zq2599@gmail.com
 * @Title: 服务消费者
 * @Package
 * @Description:
 * @date 7/30/21 2:53 下午
 */
@SpringBootApplication
@RestController
public class ConsumerApplication {
    @Autowired
    private OkHttpClient.Builder builder;


    public static void main(String[] args) {
        SpringApplication.run(ConsumerApplication.class, args);
    }

    @GetMapping("/")
    public String hello() throws IOException {
        Request request = new Request.Builder()
                .url("http://serviceId/hello").build();
        Response response = builder.build().newCall(request).execute();


        return new Date().toString();
    }
}
kubectl create -f tomcat.yaml
kubectl create -f tomcat-svc.yaml
kubectl create -f nginx.yaml
kubectl create -f nginx-svc.yaml
echo ""
echo "nginx and tomcat running now"


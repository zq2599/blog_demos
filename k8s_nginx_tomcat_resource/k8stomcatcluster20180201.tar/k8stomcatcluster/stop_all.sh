kubectl delete service tomcathost
kubectl delete deployment tomcathost
kubectl delete service ng
kubectl delete deployment ng
echo "nginx and tomcat stop now"


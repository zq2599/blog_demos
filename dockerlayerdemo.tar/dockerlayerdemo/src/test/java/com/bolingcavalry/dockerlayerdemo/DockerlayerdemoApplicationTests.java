package com.bolingcavalry.dockerlayerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerlayerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

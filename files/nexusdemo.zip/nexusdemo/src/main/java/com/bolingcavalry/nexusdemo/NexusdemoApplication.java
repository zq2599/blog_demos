package com.bolingcavalry.nexusdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NexusdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(NexusdemoApplication.class, args);
    }

}
